ГРУЗ КАЗАХСТАН v2.3 — ANDROID BUILD

Исходный Flutter-проект подготовлен для релизной сборки. Android/iOS platform scaffolding не хранится в архиве, потому что оно генерируется Flutter SDK с актуальным Gradle-шаблоном.

ПЕРЕД СБОРКОЙ:
1. Установите стабильный Flutter SDK (Dart >= 3.5).
2. В каталоге mobile выполните: bash ../tooling/bootstrap_platforms.sh
3. Для 2GIS положите полученный `dgissdk.key` в `mobile/assets/` и проверьте, что он добавлен в `pubspec.yaml` как asset. Ключ создаётся в Platform Manager 2GIS для конкретного appId.
4. Для Firebase положите `google-services.json` в `mobile/android/app/` после генерации Android-платформы.
5. Выполните `flutter analyze`.
6. Выполните `flutter build appbundle --release`.

Google Play принимает Android App Bundle (.aab); перед публикацией нужен release/upload key. Не добавляйте секреты, keystore или Firebase credentials в Git.
