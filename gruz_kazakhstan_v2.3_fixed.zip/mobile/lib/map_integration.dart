// Груз Казахстан v1.0 — слой интеграции карты.
// После получения dgissdk.key сюда подключается dgis_mobile_sdk_full.
// Не храните API-ключи в GitHub или в открытом чате.

class MapPoint {
  final String address;
  final double latitude;
  final double longitude;
  const MapPoint({required this.address, required this.latitude, required this.longitude});
}

class MapRouteDraft {
  final List<MapPoint> points;
  const MapRouteDraft(this.points);

  bool get isValid => points.length >= 2;
}
