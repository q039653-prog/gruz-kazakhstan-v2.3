# Груз Казахстан — v2.3 release readiness

## Fixed in this source package
- Removed the duplicate Prisma `20260930_initial_schema` migration that recreated the whole database schema.
- Kept a linear migration history: `20260929_v00_init` -> `20260929_v16_payment` -> `20260930_v23_vehicle_types`.
- Aligned app/API versions to Flutter `2.3.0+23` / API `2.3.0`.
- Removed the duplicate `JWT_SECRET` entry from `.env.example`.
- Updated Android bootstrap so the generated Gradle project receives the official 2GIS Maven repository.
- Updated CI to use the same bootstrap path.
- Added `.gitignore` rules for keystores, Firebase config, 2GIS key, environment files and generated output.

## Still requires owner credentials / release environment
- Flutter stable + Android SDK for the actual AAB build.
- Firebase `google-services.json` for Android push notifications.
- 2GIS `dgissdk.key` for the mobile map.
- Production PostgreSQL `DATABASE_URL`.
- Long random production `JWT_SECRET`.
- SMSC credentials.
- Payment provider credentials if real payments are enabled.
- Google Play upload key / Play App Signing.

## Important
A source archive cannot honestly be called fully production-ready until `flutter analyze`, `flutter build appbundle --release`, a clean Prisma migration against an empty PostgreSQL database, and end-to-end tests pass in the real release environment.
