import { PrismaClient, UserRole } from '@prisma/client';
import * as bcrypt from 'bcryptjs';
const prisma = new PrismaClient();
async function main(){
  const phone=process.env.ADMIN_PHONE || '+77000000000';
  const password=process.env.ADMIN_PASSWORD || 'ChangeMe123!';
  await prisma.user.upsert({where:{phone},update:{role:UserRole.ADMIN,passwordHash:await bcrypt.hash(password,10)},create:{phone,name:'Администратор',role:UserRole.ADMIN,passwordHash:await bcrypt.hash(password,10)}});
  console.log(`Admin: ${phone}`);
}
main().finally(()=>prisma.$disconnect());
