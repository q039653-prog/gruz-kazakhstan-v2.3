-- Груз Казахстан: базовая схема до платёжного блока.
-- Создаёт базовую доменную модель на чистой PostgreSQL-базе; последующие миграции добавляют платежи и расширенные типы транспорта.

CREATE TYPE "UserRole" AS ENUM ('CUSTOMER','DRIVER','ADMIN');
CREATE TYPE "DriverStatus" AS ENUM ('PENDING','VERIFIED','REJECTED','BLOCKED');
CREATE TYPE "DocumentStatus" AS ENUM ('PENDING','VERIFIED','REJECTED');
CREATE TYPE "OfferStatus" AS ENUM ('PENDING','ACCEPTED','REJECTED','WITHDRAWN');
CREATE TYPE "OrderStatus" AS ENUM ('CREATED','SEARCHING','DRIVER_SELECTED','EN_ROUTE_TO_PICKUP','ARRIVED','CARGO_PICKED','UP_IN_TRANSIT','DELIVERED','COMPLETED','CANCELLED');
CREATE TYPE "VehicleType" AS ENUM ('GAZELLE','VAN','FLATBED','TRUCK','HEAVY_TRUCK','OTHER');
CREATE TYPE "FinanceType" AS ENUM ('DRIVER_EARNING','PLATFORM_COMMISSION','ADJUSTMENT','PAYOUT','REFUND');
CREATE TYPE "FinanceStatus" AS ENUM ('POSTED','PENDING','REVERSED');
CREATE TYPE "PayoutStatus" AS ENUM ('PENDING','APPROVED','REJECTED','PAID');

CREATE TABLE "OtpChallenge" (
  "id" TEXT NOT NULL,
  "phone" TEXT NOT NULL,
  "purpose" TEXT NOT NULL,
  "codeHash" TEXT NOT NULL,
  "expiresAt" TIMESTAMP(3) NOT NULL,
  "attempts" INTEGER NOT NULL DEFAULT 0,
  "consumedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "OtpChallenge_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "OtpChallenge_phone_purpose_createdAt_idx" ON "OtpChallenge"("phone","purpose","createdAt");

CREATE TABLE "User" (
  "id" TEXT NOT NULL,
  "phone" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "surname" TEXT,
  "role" "UserRole" NOT NULL,
  "passwordHash" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "User_phone_key" ON "User"("phone");

CREATE TABLE "Driver" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "status" "DriverStatus" NOT NULL DEFAULT 'PENDING',
  "city" TEXT,
  "licenseNumber" TEXT,
  "licensePhotoUrl" TEXT,
  "experienceYears" INTEGER,
  "rating" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "completedTrips" INTEGER NOT NULL DEFAULT 0,
  "online" BOOLEAN NOT NULL DEFAULT false,
  "profilePhotoUrl" TEXT,
  "rejectionReason" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  "currentLat" DOUBLE PRECISION,
  "currentLon" DOUBLE PRECISION,
  "locationUpdatedAt" TIMESTAMP(3),
  "walletBalanceKzt" INTEGER NOT NULL DEFAULT 0,
  "totalEarnedKzt" INTEGER NOT NULL DEFAULT 0,
  "totalCommissionKzt" INTEGER NOT NULL DEFAULT 0,
  CONSTRAINT "Driver_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Driver_userId_key" ON "Driver"("userId");

CREATE TABLE "Vehicle" (
  "id" TEXT NOT NULL,
  "driverId" TEXT NOT NULL,
  "type" "VehicleType" NOT NULL,
  "make" TEXT,
  "model" TEXT,
  "year" INTEGER,
  "plate" TEXT,
  "capacityKg" INTEGER,
  "volumeM3" DOUBLE PRECISION,
  "photoUrl" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Vehicle_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "Vehicle_driverId_idx" ON "Vehicle"("driverId");

CREATE TABLE "Order" (
  "id" TEXT NOT NULL,
  "customerId" TEXT NOT NULL,
  "driverId" TEXT,
  "status" "OrderStatus" NOT NULL DEFAULT 'CREATED',
  "cargoDescription" TEXT NOT NULL,
  "weightKg" INTEGER,
  "volumeM3" DOUBLE PRECISION,
  "priceKzt" INTEGER NOT NULL,
  "allowBackhaul" BOOLEAN NOT NULL DEFAULT false,
  "scheduledAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Order_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "Order_customerId_createdAt_idx" ON "Order"("customerId","createdAt");
CREATE INDEX "Order_driverId_createdAt_idx" ON "Order"("driverId","createdAt");
CREATE INDEX "Order_status_createdAt_idx" ON "Order"("status","createdAt");

CREATE TABLE "Route" (
  "id" TEXT NOT NULL,
  "orderId" TEXT NOT NULL,
  "distanceM" INTEGER NOT NULL,
  "durationSec" INTEGER NOT NULL,
  "geometryJson" TEXT,
  "provider" TEXT NOT NULL DEFAULT '2GIS',
  "calculatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Route_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Route_orderId_key" ON "Route"("orderId");

CREATE TABLE "DriverLocation" (
  "id" TEXT NOT NULL,
  "driverId" TEXT NOT NULL,
  "latitude" DOUBLE PRECISION NOT NULL,
  "longitude" DOUBLE PRECISION NOT NULL,
  "accuracyM" DOUBLE PRECISION,
  "recordedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "DriverLocation_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "DriverLocation_driverId_recordedAt_idx" ON "DriverLocation"("driverId","recordedAt");

CREATE TABLE "OrderPoint" (
  "id" TEXT NOT NULL,
  "orderId" TEXT NOT NULL,
  "sequence" INTEGER NOT NULL,
  "address" TEXT NOT NULL,
  "latitude" DOUBLE PRECISION,
  "longitude" DOUBLE PRECISION,
  CONSTRAINT "OrderPoint_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "OrderPoint_orderId_sequence_idx" ON "OrderPoint"("orderId","sequence");

CREATE TABLE "Offer" (
  "id" TEXT NOT NULL,
  "orderId" TEXT NOT NULL,
  "driverId" TEXT NOT NULL,
  "priceKzt" INTEGER NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  "expiresAt" TIMESTAMP(3),
  "status" "OfferStatus" NOT NULL DEFAULT 'PENDING',
  CONSTRAINT "Offer_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Offer_orderId_driverId_key" ON "Offer"("orderId","driverId");
CREATE INDEX "Offer_orderId_status_expiresAt_idx" ON "Offer"("orderId","status","expiresAt");
CREATE INDEX "Offer_driverId_updatedAt_idx" ON "Offer"("driverId","updatedAt");

CREATE TABLE "NotificationToken" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "token" TEXT NOT NULL,
  "platform" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "NotificationToken_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "NotificationToken_token_key" ON "NotificationToken"("token");
CREATE INDEX "NotificationToken_userId_idx" ON "NotificationToken"("userId");

CREATE TABLE "Message" (
  "id" TEXT NOT NULL,
  "orderId" TEXT NOT NULL,
  "senderId" TEXT NOT NULL,
  "text" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Message_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "Message_orderId_createdAt_idx" ON "Message"("orderId","createdAt");

CREATE TABLE "OrderEvent" (
  "id" TEXT NOT NULL,
  "orderId" TEXT NOT NULL,
  "status" "OrderStatus" NOT NULL,
  "note" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "OrderEvent_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "OrderEvent_orderId_createdAt_idx" ON "OrderEvent"("orderId","createdAt");

CREATE TABLE "Rating" (
  "id" TEXT NOT NULL,
  "orderId" TEXT NOT NULL,
  "fromUserId" TEXT NOT NULL,
  "toUserId" TEXT NOT NULL,
  "stars" INTEGER NOT NULL,
  "comment" TEXT,
  CONSTRAINT "Rating_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "Rating_orderId_idx" ON "Rating"("orderId");
CREATE INDEX "Rating_toUserId_idx" ON "Rating"("toUserId");

CREATE TABLE "DriverDocument" (
  "id" TEXT NOT NULL,
  "driverId" TEXT NOT NULL,
  "type" TEXT NOT NULL,
  "number" TEXT,
  "photoUrl" TEXT,
  "status" "DocumentStatus" NOT NULL DEFAULT 'PENDING',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "DriverDocument_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "DriverDocument_driverId_idx" ON "DriverDocument"("driverId");

CREATE TABLE "CommissionSetting" (
  "id" TEXT NOT NULL,
  "percent" DOUBLE PRECISION NOT NULL DEFAULT 10,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "CommissionSetting_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "FinancialTransaction" (
  "id" TEXT NOT NULL,
  "orderId" TEXT,
  "userId" TEXT,
  "type" "FinanceType" NOT NULL,
  "status" "FinanceStatus" NOT NULL DEFAULT 'POSTED',
  "amountKzt" INTEGER NOT NULL,
  "description" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "FinancialTransaction_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "FinancialTransaction_userId_createdAt_idx" ON "FinancialTransaction"("userId","createdAt");
CREATE INDEX "FinancialTransaction_orderId_idx" ON "FinancialTransaction"("orderId");

CREATE TABLE "PayoutRequest" (
  "id" TEXT NOT NULL,
  "driverId" TEXT NOT NULL,
  "amountKzt" INTEGER NOT NULL,
  "method" TEXT NOT NULL,
  "destinationLast4" TEXT,
  "status" "PayoutStatus" NOT NULL DEFAULT 'PENDING',
  "adminNote" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "PayoutRequest_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "PayoutRequest_driverId_createdAt_idx" ON "PayoutRequest"("driverId","createdAt");
CREATE INDEX "PayoutRequest_status_createdAt_idx" ON "PayoutRequest"("status","createdAt");

ALTER TABLE "Driver" ADD CONSTRAINT "Driver_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Vehicle" ADD CONSTRAINT "Vehicle_driverId_fkey" FOREIGN KEY ("driverId") REFERENCES "Driver"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Order" ADD CONSTRAINT "Order_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Order" ADD CONSTRAINT "Order_driverId_fkey" FOREIGN KEY ("driverId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "Route" ADD CONSTRAINT "Route_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "Order"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "DriverLocation" ADD CONSTRAINT "DriverLocation_driverId_fkey" FOREIGN KEY ("driverId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "OrderPoint" ADD CONSTRAINT "OrderPoint_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "Order"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Offer" ADD CONSTRAINT "Offer_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "Order"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Offer" ADD CONSTRAINT "Offer_driverId_fkey" FOREIGN KEY ("driverId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "NotificationToken" ADD CONSTRAINT "NotificationToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Message" ADD CONSTRAINT "Message_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "OrderEvent" ADD CONSTRAINT "OrderEvent_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "Order"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Rating" ADD CONSTRAINT "Rating_fromUserId_fkey" FOREIGN KEY ("fromUserId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Rating" ADD CONSTRAINT "Rating_toUserId_fkey" FOREIGN KEY ("toUserId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "DriverDocument" ADD CONSTRAINT "DriverDocument_driverId_fkey" FOREIGN KEY ("driverId") REFERENCES "Driver"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "FinancialTransaction" ADD CONSTRAINT "FinancialTransaction_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "Order"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "FinancialTransaction" ADD CONSTRAINT "FinancialTransaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "PayoutRequest" ADD CONSTRAINT "PayoutRequest_driverId_fkey" FOREIGN KEY ("driverId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
