#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../mobile"
command -v flutter >/dev/null 2>&1 || { echo 'Flutter SDK is required. Install stable Flutter first.'; exit 1; }
flutter create --platforms=android,ios --org kz.gruzkazakhstan .
python3 - <<'PY'
from pathlib import Path
import re
candidates=[Path('android/settings.gradle.kts'), Path('android/settings.gradle')]
p=next((x for x in candidates if x.exists()), None)
if p is None:
    raise SystemExit('Flutter did not generate android/settings.gradle(.kts)')
s=p.read_text()
repo='https://artifactory.2gis.dev/sdk-maven-release'
if repo not in s:
    m=re.search(r'dependencyResolutionManagement\s*\{(?P<body>[\s\S]*?)\n\}', s)
    if not m or 'repositories {' not in m.group('body'):
        raise SystemExit('Could not locate dependencyResolutionManagement.repositories')
    body=m.group('body')
    if p.suffix == '.kts':
        addition='repositories {\n        maven { url = uri("'+repo+'") }'
    else:
        addition='repositories {\n        maven { url "'+repo+'" }'
    body=body.replace('repositories {', addition, 1)
    p.write_text(s[:m.start('body')]+body+s[m.end('body'):])
PY
flutter pub get
flutter analyze
