# Груз Казахстан API v2.3

NestJS + Prisma/PostgreSQL backend для приложения «Груз Казахстан».

## Локальный запуск
1. Node.js 20+ и Docker.
2. Скопировать `.env.example` в `.env`.
3. Запустить PostgreSQL: `docker compose up -d`.
4. `npm install`.
5. `npx prisma generate`.
6. `npx prisma migrate deploy`.
7. `npm run build`.
8. `npm start`.

API health: `http://localhost:3000/api/health`

## Production
Обязательны: DATABASE_URL, JWT_SECRET, SMSC, 2GIS, Firebase и платежные credentials по фактическим используемым функциям.

`PAYMENT_PROVIDER=UNCONFIGURED` оставляет платежи неподключёнными. Для Freedom Pay нужны merchant ID, secret key и публичный HTTPS URL.

Ручное подтверждение платежа (`/admin/payments/mark-paid`) в production отключено, если явно не задано `ALLOW_MANUAL_PAYMENT_CONFIRMATION=true`.

## Миграции
История миграций идёт последовательно: базовая схема → payment → v2.3 vehicle types → v2.3 integrity. Дублирующей initial migration больше нет.
