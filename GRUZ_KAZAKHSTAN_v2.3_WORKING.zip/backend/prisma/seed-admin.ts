import { PrismaClient, UserRole } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  const phone = String(process.env.ADMIN_PHONE || '').trim();
  const password = String(process.env.ADMIN_PASSWORD || '');
  if (!/^\+?[0-9]{10,15}$/.test(phone)) throw new Error('ADMIN_PHONE must be a valid phone number.');
  if (password.length < 12) throw new Error('ADMIN_PASSWORD must contain at least 12 characters.');

  const passwordHash = await bcrypt.hash(password, 12);
  await prisma.user.upsert({
    where: { phone },
    update: { role: UserRole.ADMIN, passwordHash },
    create: { phone, name: 'Администратор', role: UserRole.ADMIN, passwordHash },
  });
  console.log(`Admin created/updated for ${phone}`);
}

main().catch(err => { console.error(err); process.exitCode = 1; }).finally(() => prisma.$disconnect());
