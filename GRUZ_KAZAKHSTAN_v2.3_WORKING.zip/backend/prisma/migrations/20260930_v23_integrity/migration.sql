-- v2.3 integrity constraints: message/order relation and one rating per participant per order.
ALTER TABLE "Message" ADD CONSTRAINT "Message_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "Order"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
CREATE INDEX "Message_orderId_createdAt_idx" ON "Message"("orderId", "createdAt");
CREATE UNIQUE INDEX "Rating_orderId_fromUserId_key" ON "Rating"("orderId", "fromUserId");
