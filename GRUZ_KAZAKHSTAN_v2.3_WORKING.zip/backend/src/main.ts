import 'reflect-metadata';
import { Body, Controller, Get, Headers, HttpException, Injectable, Module, Post, Query, Param, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { JwtModule, JwtService } from '@nestjs/jwt';
import { NestFactory } from '@nestjs/core';
import { PrismaClient, UserRole, OrderStatus, VehicleType, DriverStatus, DocumentStatus, OfferStatus, PaymentStatus } from '@prisma/client';
import * as bcrypt from 'bcryptjs';
import * as express from 'express';
import * as path from 'path';
import * as fs from 'fs';
import { randomInt, createHash } from 'crypto';
import type { Request, Response, NextFunction } from 'express';
import { diskStorage } from 'multer';
import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getMessaging } from 'firebase-admin/messaging';

const prisma = new PrismaClient();

const DIGIS_KEY = process.env.DGIS_API_KEY || '';
const PAYMENT_PROVIDER = process.env.PAYMENT_PROVIDER || 'UNCONFIGURED';
const FREEDOMPAY_MERCHANT_ID = process.env.FREEDOMPAY_MERCHANT_ID || '';
const FREEDOMPAY_SECRET_KEY = process.env.FREEDOMPAY_SECRET_KEY || '';
const PUBLIC_BASE_URL = (process.env.PUBLIC_BASE_URL || '').replace(/\/$/, '');

function initFirebase() {
  const projectId = process.env.FIREBASE_PROJECT_ID || '';
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL || '';
  const privateKey = (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
  if (!projectId || !clientEmail || !privateKey) return false;
  if (!getApps().length) initializeApp({ credential: cert({ projectId, clientEmail, privateKey }) });
  return true;
}

async function pushToUsers(userIds: string[], title: string, body: string, data: Record<string,string> = {}) {
  try {
    if (!initFirebase() || !userIds.length) return { sent: 0 };
    const rows = await prisma.notificationToken.findMany({ where: { userId: { in: userIds } }, select: { token: true } });
    const tokens = rows.map(x => x.token);
    if (!tokens.length) return { sent: 0 };
    const r = await getMessaging().sendEachForMulticast({ tokens, notification: { title, body }, data });
    const bad = r.responses.map((x,i) => x.success ? null : tokens[i]).filter(Boolean) as string[];
    if (bad.length) await prisma.notificationToken.deleteMany({ where: { token: { in: bad } } });
    return { sent: r.successCount };
  } catch (e) {
    console.error('FCM error:', e);
    return { sent: 0 };
  }
}

function freedomSalt() { return Math.random().toString(36).slice(2, 18) + Date.now().toString(36); }
function freedomSignature(script: string, fields: Record<string, any>, secret: string) {
  const values = Object.keys(fields).filter(k => k !== 'pg_sig').sort().map(k => String(fields[k] ?? ''));
  return createHash('md5').update([script, ...values, secret].join(';')).digest('hex');
}
function decodeXml(value: string) {
  return value.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'");
}
function parseXmlResponse(xml: string) {
  const out: Record<string,string> = {};
  for (const m of xml.matchAll(/<([A-Za-z0-9_]+)>([\s\S]*?)<\/\1>/g)) out[m[1]] = decodeXml(m[2]);
  return out;
}
async function freedomPayCreate(order: any, customer: any, paymentId: string) {
  if (PAYMENT_PROVIDER !== 'FREEDOMPAY') return null;
  if (!FREEDOMPAY_MERCHANT_ID || !FREEDOMPAY_SECRET_KEY || !PUBLIC_BASE_URL) throw new HttpException('Freedom Pay не настроен: нужны FREEDOMPAY_MERCHANT_ID, FREEDOMPAY_SECRET_KEY и PUBLIC_BASE_URL.', 503);
  const fields: Record<string, any> = {
    pg_merchant_id: FREEDOMPAY_MERCHANT_ID, pg_amount: order.priceKzt.toFixed(2), pg_currency: 'KZT',
    pg_description: `Оплата заказа Груз Казахстан ${order.id}`, pg_order_id: paymentId, pg_salt: freedomSalt(),
    pg_result_url: `${PUBLIC_BASE_URL}/api/payments/freedompay/result`,
    pg_success_url: `${PUBLIC_BASE_URL}/api/payments/freedompay/success`,
    pg_failure_url: `${PUBLIC_BASE_URL}/api/payments/freedompay/failure`,
    pg_lifetime: 86400, pg_auto_clearing: 1
  };
  if (customer?.phone) fields.pg_user_phone = String(customer.phone).replace(/^\+/, '');
  fields.pg_sig = freedomSignature('/init_payment', fields, FREEDOMPAY_SECRET_KEY);
  const body = JSON.stringify(fields);
  const r = await fetch('https://api.freedompay.kz/init_payment', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body });
  const raw = await r.text();
  const data = parseXmlResponse(raw);
  if (!r.ok || data.pg_status !== 'ok' || !data.pg_redirect_url) throw new HttpException(data.pg_error_description || 'Freedom Pay не создал платёж', 502);
  return { providerRef: data.pg_payment_id || null, paymentUrl: data.pg_redirect_url };
}

async function twoGisRoute(points: Array<{latitude:number; longitude:number}>, vehicle: any = null) {
  if (!DIGIS_KEY) throw new HttpException('Ключ 2ГИС ещё не настроен на сервере. Укажите DGIS_API_KEY.', 503);
  if (points.length < 2) throw new HttpException('Для маршрута нужны минимум 2 точки', 400);
  if (points.length > 10) throw new HttpException('Слишком много точек маршрута', 400);
  const body: any = {
    points: points.map((p, i) => ({ lon: p.longitude, lat: p.latitude, type: i === 0 || i === points.length - 1 ? 'stop' : 'pref', ...(i === 0 ? { start: true } : {}) })),
    transport: vehicle?.type === 'TRUCK' || vehicle?.type === 'HEAVY_TRUCK' || vehicle?.capacityKg > 1000 ? 'truck' : 'driving',
    output: 'detailed', locale: 'ru', route_mode: 'fastest', traffic_mode: 'jam'
  };
  if (body.transport === 'truck' && vehicle) {
    const mass = Math.max(0.1, Number(vehicle.capacityKg || 1) / 1000);
    body.params = { truck: { mass, max_perm_mass: mass } };
  }
  const r = await fetch(`https://routing.api.2gis.com/routing/7.0.0/global?key=${encodeURIComponent(DIGIS_KEY)}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const data: any = await r.json();
  if (!r.ok || data.status !== 'OK' || !data.result?.[0]) throw new HttpException(data.message || '2ГИС не смог построить маршрут', 502);
  const result = data.result[0];
  return { distanceM: Math.round(Number(result.total_distance || 0)), durationSec: Math.round(Number(result.total_duration || 0)), geometry: result.maneuvers || null, provider: '2GIS' };
}

const uploadDir = path.join(process.cwd(), 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });

function cleanPhone(phone: string) { return String(phone || '').replace(/[^0-9+]/g, ''); }
function bearer(h: any) { const v = h?.authorization || ''; return v.startsWith('Bearer ') ? v.slice(7) : ''; }
function safeName(name: string) { return name.replace(/[^a-zA-Z0-9._-]/g, '_'); }

// Lightweight production guardrails. For a multi-instance deployment, move this to Redis.
const rateBuckets = new Map<string, { count: number; resetAt: number }>();
function rateLimit(limit: number, windowMs: number, keyPrefix: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    const key = `${keyPrefix}:${req.ip || 'unknown'}`;
    const now = Date.now();
    const item = rateBuckets.get(key);
    if (!item || item.resetAt <= now) { rateBuckets.set(key, { count: 1, resetAt: now + windowMs }); return next(); }
    if (item.count >= limit) return res.status(429).json({ message: 'Слишком много запросов. Попробуйте позже.' });
    item.count++; next();
  };
}

const OTP_TTL_MS = 5 * 60 * 1000;
const OTP_MAX_ATTEMPTS = 5;
async function sendSmsOtp(phone: string, code: string) {
  const login = process.env.SMSC_LOGIN || ''; const psw = process.env.SMSC_PASSWORD || ''; const apikey = process.env.SMSC_APIKEY || '';
  if (!apikey && !(login && psw)) throw new HttpException('SMS-провайдер не настроен. Добавьте SMSC_APIKEY или SMSC_LOGIN и SMSC_PASSWORD на сервере.', 503);
  const params = new URLSearchParams({ phones: phone.replace(/^\+/, ''), mes: `Груз Казахстан: код подтверждения ${code}. Никому его не сообщайте.` });
  if (apikey) params.set('apikey', apikey); else { params.set('login', login); params.set('psw', psw); }
  const r = await fetch('https://smsc.kz/sys/send.php', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: params.toString() });
  const body = await r.text();
  if (!r.ok || !body.startsWith('OK')) throw new HttpException('Не удалось отправить SMS-код. Проверьте настройки SMSC.', 502);
}
async function createOtp(phone: string, purpose: string) {
  const code = String(randomInt(100000, 1000000));
  await prisma.otpChallenge.updateMany({ where: { phone, purpose, consumedAt: null }, data: { consumedAt: new Date() } });
  const item = await prisma.otpChallenge.create({ data: { phone, purpose, codeHash: await bcrypt.hash(code, 10), expiresAt: new Date(Date.now() + OTP_TTL_MS) } });
  await sendSmsOtp(phone, code);
  return { id: item.id, expiresAt: item.expiresAt };
}
async function verifyOtp(phone: string, purpose: string, code: string) {
  const item = await prisma.otpChallenge.findFirst({ where: { phone, purpose, consumedAt: null }, orderBy: { createdAt: 'desc' } });
  if (!item || item.expiresAt < new Date()) throw new HttpException('Код истёк. Запросите новый код.', 400);
  if (item.attempts >= OTP_MAX_ATTEMPTS) throw new HttpException('Слишком много попыток. Запросите новый код.', 429);
  const ok = await bcrypt.compare(code, item.codeHash);
  if (!ok) { await prisma.otpChallenge.update({ where: { id: item.id }, data: { attempts: { increment: 1 } } }); throw new HttpException('Неверный код подтверждения.', 400); }
  await prisma.otpChallenge.update({ where: { id: item.id }, data: { consumedAt: new Date() } });
  return true;
}

@Injectable()
class ApiService {
  constructor(private jwt: JwtService) {}
  async userFromHeaders(h: any) {
    const token = bearer(h); if (!token) throw new HttpException('Требуется авторизация', 401);
    try {
      const p = await this.jwt.verifyAsync(token);
      const u = await prisma.user.findUnique({ where: { id: p.sub }, include: { driver: { include: { vehicles: true, documents: true } } } });
      if (!u) throw new Error(); return u;
    } catch { throw new HttpException('Недействительная авторизация', 401); }
  }
  token(u: { id: string; role: UserRole }) { return this.jwt.sign({ sub: u.id, role: u.role }); }
}

async function getCommissionPercent() {
  const row = await prisma.commissionSetting.findUnique({ where: { id: 'default' } });
  return row?.percent ?? Number(process.env.COMMISSION_PERCENT || 10);
}

async function settleCompletedOrder(orderId: string) {
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order?.driverId) return null;
  const already = await prisma.financialTransaction.findFirst({ where: { orderId, type: 'DRIVER_EARNING', status: 'POSTED' } });
  if (already) return already;
  const percent = Math.max(0, Math.min(100, await getCommissionPercent()));
  const commission = Math.round(order.priceKzt * percent / 100);
  const earning = Math.max(0, order.priceKzt - commission);
  return prisma.$transaction(async tx => {
    const existing = await tx.financialTransaction.findFirst({ where: { orderId, type: 'DRIVER_EARNING', status: 'POSTED' } });
    if (existing) return existing;
    await tx.financialTransaction.create({ data: { orderId, userId: order.driverId, type: 'DRIVER_EARNING', amountKzt: earning, description: `Заработок за заказ ${order.id}` } });
    await tx.financialTransaction.create({ data: { orderId, userId: null, type: 'PLATFORM_COMMISSION', amountKzt: commission, description: `Комиссия ${percent}% за заказ ${order.id}` } });
    await tx.driver.update({ where: { userId: order.driverId }, data: { walletBalanceKzt: { increment: earning }, totalEarnedKzt: { increment: earning }, totalCommissionKzt: { increment: commission } } });
    return tx.financialTransaction.findFirst({ where: { orderId, type: 'DRIVER_EARNING', status: 'POSTED' } });
  });
}

@Controller('/api')
class AppController {
  constructor(private api: ApiService) {}

  @Get('/health') health() { return { ok: true, service: 'Груз Казахстан API', version: '2.3.0', paymentProvider: PAYMENT_PROVIDER, push: Boolean(process.env.FIREBASE_PROJECT_ID && process.env.FIREBASE_CLIENT_EMAIL && process.env.FIREBASE_PRIVATE_KEY) }; }

  @Post('/auth/register/start') async registerStart(@Body() b: any) {
    const phone = cleanPhone(b.phone), name = String(b.name || '').trim(), surname = String(b.surname || '').trim() || null, password = String(b.password || '');
    const role = b.role === 'DRIVER' ? UserRole.DRIVER : UserRole.CUSTOMER;
    if (!/^\+?[0-9]{10,15}$/.test(phone)) throw new HttpException('Введите корректный номер телефона', 400);
    if (!name || name.length < 2) throw new HttpException('Введите имя', 400);
    if (password.length < 8) throw new HttpException('Пароль должен содержать минимум 8 символов', 400);
    if (await prisma.user.findUnique({ where: { phone } })) throw new HttpException('Пользователь с таким номером уже зарегистрирован', 409);
    const otp = await createOtp(phone, 'REGISTER');
    return { challengeId: otp.id, expiresAt: otp.expiresAt, message: 'Код подтверждения отправлен по SMS' };
  }

  @Post('/auth/register/verify') async registerVerify(@Body() b: any) {
    const phone = cleanPhone(b.phone), code = String(b.code || '').trim(), name = String(b.name || '').trim(), surname = String(b.surname || '').trim() || null, password = String(b.password || '');
    const role = b.role === 'DRIVER' ? UserRole.DRIVER : UserRole.CUSTOMER;
    if (!/^\+?[0-9]{10,15}$/.test(phone)) throw new HttpException('Введите корректный номер телефона', 400);
    if (!name || name.length < 2) throw new HttpException('Введите имя', 400);
    if (password.length < 8) throw new HttpException('Пароль должен содержать минимум 8 символов', 400);
    if (!/^\d{6}$/.test(code)) throw new HttpException('Введите 6-значный код из SMS', 400);
    await verifyOtp(phone, 'REGISTER', code);
    if (await prisma.user.findUnique({ where: { phone } })) throw new HttpException('Пользователь с таким номером уже зарегистрирован', 409);
    const user = await prisma.user.create({ data: { phone, name, surname, role, passwordHash: await bcrypt.hash(password, 12), driver: role === UserRole.DRIVER ? { create: { status: DriverStatus.PENDING } } : undefined }, include: { driver: { include: { vehicles: true, documents: true } } } });
    return { token: this.api.token(user), user: publicUser(user) };
  }

  @Post('/auth/password/request') async passwordRequest(@Body() b: any) {
    const phone = cleanPhone(b.phone);
    if (!/^\+?[0-9]{10,15}$/.test(phone)) throw new HttpException('Введите корректный номер телефона', 400);
    const user = await prisma.user.findUnique({ where: { phone } });
    if (!user) return { message: 'Если номер зарегистрирован, код восстановления будет отправлен по SMS.' };
    const otp = await createOtp(phone, 'PASSWORD_RESET');
    return { challengeId: otp.id, expiresAt: otp.expiresAt, message: 'Код восстановления отправлен по SMS' };
  }

  @Post('/auth/password/reset') async passwordReset(@Body() b: any) {
    const phone = cleanPhone(b.phone), code = String(b.code || '').trim(), password = String(b.password || '');
    if (!/^\+?[0-9]{10,15}$/.test(phone)) throw new HttpException('Введите корректный номер телефона', 400);
    if (!/^\d{6}$/.test(code)) throw new HttpException('Введите 6-значный код из SMS', 400);
    if (password.length < 8) throw new HttpException('Пароль должен содержать минимум 8 символов', 400);
    await verifyOtp(phone, 'PASSWORD_RESET', code);
    const user = await prisma.user.findUnique({ where: { phone } });
    if (!user) throw new HttpException('Пользователь не найден', 404);
    await prisma.user.update({ where: { id: user.id }, data: { passwordHash: await bcrypt.hash(password, 12) } });
    return { message: 'Пароль изменён. Теперь можно войти.' };
  }

  @Post('/auth/register') async registerLegacy(@Body() b: any) { throw new HttpException('Регистрация теперь требует подтверждения телефона по SMS. Используйте /auth/register/start.', 410); }

  @Post('/auth/login') async login(@Body() b: any) {
    const phone = cleanPhone(b.phone), password = String(b.password || '');
    const u = await prisma.user.findUnique({ where: { phone }, include: { driver: { include: { vehicles: true, documents: true } } } });
    if (!u || !(await bcrypt.compare(password, u.passwordHash))) throw new HttpException('Неверный телефон или пароль', 401);
    return { token: this.api.token(u), user: publicUser(u) };
  }

  @Get('/me') async me(@Headers() h: any) { return publicUser(await this.api.userFromHeaders(h)); }

  @Post('/uploads') @UseInterceptors(FileInterceptor('file', { storage: diskStorage({ destination: uploadDir, filename: (_r, file, cb) => cb(null, `${Date.now()}-${safeName(file.originalname)}`) }), limits: { fileSize: 10 * 1024 * 1024 }, fileFilter: (_r, file, cb) => cb(null, /^image\/(jpeg|png|webp)$/.test(file.mimetype)) }))
  async upload(@Headers() h: any, @UploadedFile() file: Express.Multer.File) {
    await this.api.userFromHeaders(h); if (!file) throw new HttpException('Нужна фотография JPG, PNG или WEBP до 10 МБ', 400);
    return { url: `/uploads/${file.filename}`, filename: file.filename };
  }

  @Post('/driver/profile') async driverProfile(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.DRIVER) throw new HttpException('Только для водителя', 403);
    const d = await prisma.driver.update({ where: { userId: u.id }, data: { status: DriverStatus.PENDING, city: String(b.city || '').trim() || null, licenseNumber: String(b.licenseNumber || '').trim() || null, licensePhotoUrl: String(b.licensePhotoUrl || '').trim() || null, experienceYears: b.experienceYears == null ? null : Number(b.experienceYears), profilePhotoUrl: String(b.profilePhotoUrl || '').trim() || null, rejectionReason: null } });
    if (b.vehicle) {
      const v = b.vehicle; const type = String(v.type || 'OTHER').toUpperCase() as VehicleType;
      const existing = await prisma.vehicle.findFirst({ where: { driverId: d.id } });
      const data = { type: Object.values(VehicleType).includes(type) ? type : VehicleType.OTHER, make: String(v.make || '').trim() || null, model: String(v.model || '').trim() || null, year: v.year == null ? null : Number(v.year), plate: String(v.plate || '').trim() || null, capacityKg: v.capacityKg == null ? null : Number(v.capacityKg), volumeM3: v.volumeM3 == null ? null : Number(v.volumeM3), bodyType: String(v.bodyType || '').trim() || null, features: String(v.features || '').trim() || null, photoUrl: String(v.photoUrl || '').trim() || null };
      if (existing) await prisma.vehicle.update({ where: { id: existing.id }, data }); else await prisma.vehicle.create({ data: { ...data, driverId: d.id } });
    }
    if (Array.isArray(b.documents)) {
      for (const x of b.documents) await prisma.driverDocument.create({ data: { driverId: d.id, type: String(x.type || 'OTHER'), number: String(x.number || '').trim() || null, photoUrl: String(x.photoUrl || '').trim() || null, status: DocumentStatus.PENDING } });
    }
    const full = await prisma.user.findUnique({ where: { id: u.id }, include: { driver: { include: { vehicles: true, documents: true } } } });
    return publicUser(full);
  }

  @Get('/driver/me') async driverMe(@Headers() h: any) { const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.DRIVER) throw new HttpException('Только для водителя', 403); return publicUser(u); }

  @Post('/driver/online') async online(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.DRIVER) throw new HttpException('Только для водителя', 403);
    if (!u.driver || u.driver.status !== DriverStatus.VERIFIED) throw new HttpException('Водитель ещё не проверен администратором', 403);
    return prisma.driver.update({ where: { userId: u.id }, data: { online: Boolean(b.online) } });
  }

  @Post('/orders') async createOrder(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.CUSTOMER) throw new HttpException('Заказ может создать только заказчик', 403);
    const cargo = String(b.cargoDescription || '').trim(), price = Number(b.priceKzt), points = Array.isArray(b.points) ? b.points : [];
    const weightKg = b.weightKg == null ? null : Number(b.weightKg);
    const volumeM3 = b.volumeM3 == null ? null : Number(b.volumeM3);
    const scheduledAt = b.scheduledAt ? new Date(b.scheduledAt) : null;
    if (!cargo || cargo.length > 2000 || !Number.isFinite(price) || price <= 0 || price > 100000000 || points.length < 2 || points.length > 10) throw new HttpException('Нужны груз, корректная цена и от 2 до 10 точек маршрута', 400);
    if (weightKg != null && (!Number.isFinite(weightKg) || weightKg <= 0 || weightKg > 1000000)) throw new HttpException('Некорректный вес груза', 400);
    if (volumeM3 != null && (!Number.isFinite(volumeM3) || volumeM3 <= 0 || volumeM3 > 10000)) throw new HttpException('Некорректный объём груза', 400);
    if (scheduledAt && Number.isNaN(scheduledAt.getTime())) throw new HttpException('Некорректная дата доставки', 400);
    const normalizedPoints = points.map((p:any) => {
      const address = String(p.address || '').trim();
      const latitude = p.latitude == null ? null : Number(p.latitude);
      const longitude = p.longitude == null ? null : Number(p.longitude);
      if (!address) throw new HttpException('У каждой точки маршрута должен быть адрес', 400);
      if (latitude != null && (!Number.isFinite(latitude) || latitude < -90 || latitude > 90)) throw new HttpException('Некорректная широта', 400);
      if (longitude != null && (!Number.isFinite(longitude) || longitude < -180 || longitude > 180)) throw new HttpException('Некорректная долгота', 400);
      if ((latitude == null) !== (longitude == null)) throw new HttpException('Широта и долгота должны передаваться вместе', 400);
      return { address, latitude, longitude };
    });
    const order = await prisma.order.create({ data: { customerId: u.id, status: OrderStatus.SEARCHING, cargoDescription: cargo, weightKg, volumeM3, priceKzt: Math.round(price), allowBackhaul: Boolean(b.allowBackhaul), scheduledAt, points: { create: normalizedPoints.map((p, i) => ({ sequence: i, ...p })) }, events: { create: { status: OrderStatus.SEARCHING, note: 'Заказ создан и опубликован' } } }, include: { points: { orderBy: { sequence: 'asc' } } } });
    if (DIGIS_KEY && points.length >= 2 && points.every((p:any)=>p.latitude != null && p.longitude != null)) { try { const result = await twoGisRoute(points.map((p:any)=>({latitude:Number(p.latitude),longitude:Number(p.longitude)}))); await prisma.route.create({data:{orderId:order.id,distanceM:result.distanceM,durationSec:result.durationSec,geometryJson:JSON.stringify(result.geometry),provider:result.provider}}); } catch {} }
    return order;
  }

  @Get('/orders/my') async my(@Headers() h: any) {
    const u = await this.api.userFromHeaders(h);
    return prisma.order.findMany({ where: u.role === UserRole.CUSTOMER ? { customerId: u.id } : { driverId: u.id }, include: { points: { orderBy: { sequence: 'asc' } }, route: true, driver: { include: { driver: { include: { vehicles: true } } } } }, orderBy: { createdAt: 'desc' } });
  }

  @Post('/driver/location') async driverLocation(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h);
    if (u.role !== UserRole.DRIVER || !u.driver || u.driver.status !== DriverStatus.VERIFIED) throw new HttpException('Только проверенный водитель', 403);
    const lat = Number(b.latitude), lon = Number(b.longitude), accuracy = b.accuracyM == null ? null : Number(b.accuracyM);
    if (!Number.isFinite(lat) || !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) throw new HttpException('Неверные координаты', 400);
    await prisma.driver.update({ where: { userId: u.id }, data: { currentLat: lat, currentLon: lon, locationUpdatedAt: new Date() } });
    return prisma.driverLocation.create({ data: { driverId: u.id, latitude: lat, longitude: lon, accuracyM: accuracy } });
  }

  @Get('/driver/location') async driverLocationGet(@Headers() h: any) {
    const u = await this.api.userFromHeaders(h);
    if (u.role !== UserRole.DRIVER) throw new HttpException('Только для водителя', 403);
    return { latitude: u.driver?.currentLat ?? null, longitude: u.driver?.currentLon ?? null, updatedAt: u.driver?.locationUpdatedAt ?? null };
  }

  @Post('/routes/calculate') async calculateRoute(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h);
    const points = Array.isArray(b.points) ? b.points.map((p:any)=>({latitude:Number(p.latitude),longitude:Number(p.longitude)})) : [];
    if (points.length < 2 || points.length > 10 || points.some((p:any) => !Number.isFinite(p.latitude) || !Number.isFinite(p.longitude) || p.latitude < -90 || p.latitude > 90 || p.longitude < -180 || p.longitude > 180)) throw new HttpException('Неверные точки маршрута', 400);
    const result = await twoGisRoute(points);
    if (b.orderId) {
      const order = await prisma.order.findFirst({ where: { id: b.orderId, OR: [{ customerId: u.id }, { driverId: u.id }] } });
      if (!order) throw new HttpException('Заказ не найден', 404);
      await prisma.route.upsert({ where: { orderId: order.id }, update: { distanceM: result.distanceM, durationSec: result.durationSec, geometryJson: JSON.stringify(result.geometry), provider: result.provider }, create: { orderId: order.id, distanceM: result.distanceM, durationSec: result.durationSec, geometryJson: JSON.stringify(result.geometry), provider: result.provider } });
    }
    return result;
  }

  @Get('/orders/backhaul-candidates') async backhaulCandidates(@Headers() h: any, @Query('orderId') orderId: string) {
    const u = await this.api.userFromHeaders(h);
    if (u.role !== UserRole.DRIVER || !u.driver || u.driver.status !== DriverStatus.VERIFIED) throw new HttpException('Только проверенный водитель', 403);
    const active = await prisma.order.findFirst({ where: { id: orderId, driverId: u.id, status: { in: [OrderStatus.CARGO_PICKED, OrderStatus.UP_IN_TRANSIT] } }, include: { points: { orderBy: { sequence: 'asc' } } } });
    if (!active) throw new HttpException('Активный заказ не найден или груз ещё не забран', 404);
    if (active.allowBackhaul === false) throw new HttpException('Заказчик не разрешил попутный груз', 400);
    const candidates = await prisma.order.findMany({ where: { status: OrderStatus.SEARCHING, driverId: null, allowBackhaul: true, customerId: { not: u.id }, weightKg: active.weightKg == null ? undefined : { lte: Math.max(0, Number(u.driver.vehicles?.[0]?.capacityKg || 0) - active.weightKg) } }, include: { points: { orderBy: { sequence: 'asc' } } }, take: 10, orderBy: { createdAt: 'asc' } });
    const vehicle = u.driver.vehicles?.[0];
    if (!vehicle) return [];
    const current = active.points.filter((p:any)=>p.latitude != null && p.longitude != null).map((p:any)=>({latitude:p.latitude,longitude:p.longitude}));
    if (current.length < 2) return candidates.map((o:any)=>({ orderId:o.id, cargoDescription:o.cargoDescription, priceKzt:o.priceKzt, points:o.points, feasible:false, reason:'У текущего заказа нет координат маршрута' }));
    const out:any[]=[];
    for (const o of candidates) {
      const cp=o.points.filter((p:any)=>p.latitude != null && p.longitude != null).map((p:any)=>({latitude:p.latitude,longitude:p.longitude}));
      if (cp.length<2) continue;
      try {
        const base=await twoGisRoute(current, vehicle);
        const inserted=[current[0], cp[0], cp[cp.length-1], ...current.slice(1)];
        const combined=await twoGisRoute(inserted, vehicle);
        const extra=combined.durationSec-base.durationSec;
        const maxExtra=Number(process.env.BACKHAUL_MAX_EXTRA_MINUTES || 45)*60;
        out.push({ orderId:o.id,cargoDescription:o.cargoDescription,weightKg:o.weightKg,volumeM3:o.volumeM3,priceKzt:o.priceKzt,points:o.points,baseDistanceM:base.distanceM,newDistanceM:combined.distanceM,extraDurationSec:extra,feasible:extra<=maxExtra,reason:extra<=maxExtra?'Подходит по маршруту':'Слишком большой объезд' });
      } catch { out.push({ orderId:o.id,cargoDescription:o.cargoDescription,priceKzt:o.priceKzt,points:o.points,feasible:false,reason:'Не удалось рассчитать маршрут' }); }
    }
    return out;
  }

  @Post('/orders/backhaul/take') async takeBackhaul(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h);
    if (u.role !== UserRole.DRIVER || !u.driver || u.driver.status !== DriverStatus.VERIFIED) throw new HttpException('Только проверенный водитель', 403);
    const activeId = String(b.activeOrderId || '');
    const candidateId = String(b.orderId || '');
    if (!activeId || !candidateId || activeId === candidateId) throw new HttpException('Неверный заказ попутного груза', 400);

    const active = await prisma.order.findFirst({
      where: { id: activeId, driverId: u.id, status: { in: [OrderStatus.CARGO_PICKED, OrderStatus.UP_IN_TRANSIT] } },
      include: { points: { orderBy: { sequence: 'asc' } } }
    });
    if (!active) throw new HttpException('Текущий активный заказ не найден', 404);
    if (!active.allowBackhaul) throw new HttpException('Текущий заказчик не разрешил попутный груз', 400);

    const candidate = await prisma.order.findFirst({
      where: { id: candidateId, status: OrderStatus.SEARCHING, driverId: null, allowBackhaul: true },
      include: { points: { orderBy: { sequence: 'asc' } } }
    });
    if (!candidate) throw new HttpException('Этот попутный заказ уже взят или недоступен', 409);
    if (candidate.customerId === u.id) throw new HttpException('Нельзя взять собственный заказ', 400);

    const vehicle = u.driver.vehicles?.[0];
    if (!vehicle) throw new HttpException('У водителя не указан автомобиль', 400);
    if (candidate.weightKg != null && vehicle.capacityKg != null && candidate.weightKg > vehicle.capacityKg) {
      throw new HttpException('Груз превышает грузоподъёмность автомобиля', 400);
    }

    const current = active.points.filter((p:any)=>p.latitude != null && p.longitude != null).map((p:any)=>({latitude:p.latitude,longitude:p.longitude}));
    const cp = candidate.points.filter((p:any)=>p.latitude != null && p.longitude != null).map((p:any)=>({latitude:p.latitude,longitude:p.longitude}));
    if (current.length < 2 || cp.length < 2) throw new HttpException('Для попутного заказа нужны координаты маршрута', 400);
    const base = await twoGisRoute(current, vehicle);
    const inserted = [current[0], cp[0], cp[cp.length - 1], ...current.slice(1)];
    const combined = await twoGisRoute(inserted, vehicle);
    const extra = combined.durationSec - base.durationSec;
    const maxExtra = Number(process.env.BACKHAUL_MAX_EXTRA_MINUTES || 45) * 60;
    if (extra > maxExtra) throw new HttpException(`Попутный груз добавляет слишком большой объезд: ${Math.ceil(extra / 60)} мин.`, 409);

    const result = await prisma.$transaction([
      prisma.order.update({ where: { id: candidate.id }, data: { driverId: u.id, status: OrderStatus.DRIVER_SELECTED } }),
      prisma.orderEvent.create({ data: { orderId: candidate.id, status: OrderStatus.DRIVER_SELECTED, note: `Водитель взял попутный груз. Дополнительное время маршрута: ${Math.ceil(extra / 60)} мин.` } })
    ]);
    await pushToUsers([candidate.customerId], 'Водитель взял попутный груз', 'Ваш груз подключён к маршруту водителя.', { type: 'backhaul_taken', orderId: candidate.id });
    return { order: result[0], activeOrderId: active.id, extraDurationSec: extra, newDistanceM: combined.distanceM };
  }

  @Get('/orders/available') async available(@Headers() h: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.DRIVER) throw new HttpException('Только для водителя', 403);
    if (!u.driver || u.driver.status !== DriverStatus.VERIFIED) throw new HttpException('Сначала пройдите проверку документов', 403);
    return prisma.order.findMany({ where: { status: OrderStatus.SEARCHING, driverId: null }, include: { points: { orderBy: { sequence: 'asc' } }, customer: { select: { id: true, name: true, surname: true } } }, orderBy: { createdAt: 'desc' }, take: 50 });
  }

  @Post('/orders/offer') async offer(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.DRIVER || u.driver?.status !== DriverStatus.VERIFIED) throw new HttpException('Водитель не проверен', 403);
    const price = Math.round(Number(b.priceKzt)); if (!b.orderId || !Number.isFinite(price) || price <= 0) throw new HttpException('Неверное предложение', 400);
    const order = await prisma.order.findUnique({ where: { id: b.orderId }, select: { customerId: true, status: true, driverId: true } });
    if (!order || order.status !== OrderStatus.SEARCHING || order.driverId) throw new HttpException('Этот заказ уже недоступен для новых предложений', 409);
    const expiresAt = new Date(Date.now() + 30 * 60 * 1000);
    const result = await prisma.offer.upsert({ where: { orderId_driverId: { orderId: b.orderId, driverId: u.id } }, update: { priceKzt: price, status: OfferStatus.PENDING, expiresAt }, create: { orderId: b.orderId, driverId: u.id, priceKzt: price, expiresAt } });
    await pushToUsers([order.customerId], 'Новое предложение', `Водитель предложил ${price} ₸. Предложение действует 30 минут.`, { type: 'offer', orderId: b.orderId });
    return result;
  }

  @Get('/orders/offers') async offers(@Headers() h: any, @Query('orderId') orderId: string) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.CUSTOMER) throw new HttpException('Только для заказчика', 403);
    const order = await prisma.order.findFirst({ where: { id: orderId, customerId: u.id } }); if (!order) throw new HttpException('Заказ не найден', 404);
    return prisma.offer.findMany({ where: { orderId: order.id, status: OfferStatus.PENDING, OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] }, include: { driver: { include: { driver: { include: { vehicles: true } } } } }, orderBy: { priceKzt: 'asc' } });
  }

  @Post('/orders/offer/withdraw') async withdrawOffer(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.DRIVER) throw new HttpException('Только для водителя', 403);
    const offer = await prisma.offer.findFirst({ where: { orderId: b.orderId, driverId: u.id, status: OfferStatus.PENDING } });
    if (!offer) throw new HttpException('Активное предложение не найдено', 404);
    return prisma.offer.update({ where: { id: offer.id }, data: { status: OfferStatus.WITHDRAWN } });
  }

  @Get('/orders/offers/history') async offerHistory(@Headers() h: any, @Query('orderId') orderId: string) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.CUSTOMER) throw new HttpException('Только для заказчика', 403);
    const order = await prisma.order.findFirst({ where: { id: orderId, customerId: u.id } }); if (!order) throw new HttpException('Заказ не найден', 404);
    return prisma.offer.findMany({ where: { orderId }, include: { driver: { select: { id: true, name: true, surname: true } } }, orderBy: { updatedAt: 'desc' } });
  }

  @Post('/orders/select-driver') async select(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.CUSTOMER) throw new HttpException('Только для заказчика', 403);
    const order = await prisma.order.findFirst({ where: { id: b.orderId, customerId: u.id } }); if (!order) throw new HttpException('Заказ не найден', 404);
    const driver = await prisma.user.findUnique({ where: { id: b.driverId }, include: { driver: true } }); if (!driver?.driver || driver.driver.status !== DriverStatus.VERIFIED) throw new HttpException('Водитель не проверен', 400);
    const offer = await prisma.offer.findFirst({ where: { orderId: order.id, driverId: driver.id, status: OfferStatus.PENDING, OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] } });
    if (!offer) throw new HttpException('Предложение водителя не найдено', 404);
    const result = await prisma.$transaction(async tx => {
      const locked = await tx.order.updateMany({ where: { id: order.id, status: OrderStatus.SEARCHING, driverId: null }, data: { driverId: driver.id, priceKzt: offer.priceKzt, status: OrderStatus.DRIVER_SELECTED } });
      if (locked.count !== 1) throw new HttpException('Заказ уже взят или отменён. Обновите список предложений.', 409);
      await tx.offer.update({ where: { id: offer.id }, data: { status: OfferStatus.ACCEPTED } });
      await tx.offer.updateMany({ where: { orderId: order.id, id: { not: offer.id }, status: OfferStatus.PENDING }, data: { status: OfferStatus.REJECTED } });
      await tx.orderEvent.create({ data: { orderId: order.id, status: OrderStatus.DRIVER_SELECTED, note: `Выбран водитель ${driver.name} ${driver.surname || ''}`.trim() } });
      return tx.order.findUnique({ where: { id: order.id } });
    });
    await pushToUsers([driver.id], 'Водитель выбран', 'Заказ подтверждён заказчиком', { type: 'driver_selected', orderId: order.id });
    return result;
  }

  @Post('/orders/accept') async accept(@Headers() h: any, @Body() b: any) {
    await this.api.userFromHeaders(h);
    throw new HttpException('Водитель не может забрать заказ напрямую. Отправьте предложение цены — заказчик сам выберет водителя.', 409);
  }

  @Get('/orders/:orderId/events') async orderEvents(@Headers() h: any, @Param('orderId') orderId: string) {
    const u = await this.api.userFromHeaders(h);
    const order = await prisma.order.findFirst({ where: { id: orderId, OR: [{ customerId: u.id }, { driverId: u.id }] } });
    if (!order) throw new HttpException('Заказ не найден', 404);
    return prisma.orderEvent.findMany({ where: { orderId }, orderBy: { createdAt: 'asc' } });
  }

  @Post('/orders/status') async orderStatus(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h);
    const order = await prisma.order.findFirst({ where: { id: b.orderId, OR: [{ customerId: u.id }, { driverId: u.id }] } });
    if (!order) throw new HttpException('Заказ не найден', 404);
    const next = String(b.status || '') as OrderStatus;
    const note = String(b.note || '').trim();
    const allowed: Record<string, string[]> = {
      CREATED: ['CANCELLED'],
      SEARCHING: ['CANCELLED'],
      DRIVER_SELECTED: ['EN_ROUTE_TO_PICKUP','CANCELLED'],
      EN_ROUTE_TO_PICKUP: ['ARRIVED','CANCELLED'],
      ARRIVED: ['CARGO_PICKED','CANCELLED'],
      CARGO_PICKED: ['UP_IN_TRANSIT','CANCELLED'],
      UP_IN_TRANSIT: ['DELIVERED','CANCELLED'],
      DELIVERED: ['COMPLETED'],
    };
    if (!Object.values(OrderStatus).includes(next) || !(allowed[order.status] || []).includes(next)) throw new HttpException('Недопустимый переход статуса', 400);
    if (u.role === UserRole.CUSTOMER && !['CANCELLED','COMPLETED'].includes(next)) throw new HttpException('Этот статус меняет водитель', 403);
    if (next === OrderStatus.CANCELLED && !note) throw new HttpException('Укажите причину отмены заказа', 400);
    if (u.role === UserRole.DRIVER && next === 'COMPLETED') throw new HttpException('Завершение подтверждает заказчик', 403);
    if (u.role === UserRole.DRIVER && next === 'EN_ROUTE_TO_PICKUP') { const payment = await prisma.payment.findFirst({ where: { orderId: order.id }, orderBy: { createdAt: 'desc' } }); if (!payment || payment.status !== PaymentStatus.PAID) throw new HttpException('Заказчик должен оплатить заказ перед началом доставки', 402); }
    const updated = await prisma.$transaction(async tx => {
      const locked = await tx.order.updateMany({ where: { id: order.id, status: order.status }, data: { status: next } });
      if (locked.count !== 1) throw new HttpException('Статус заказа уже изменился. Обновите заказ.', 409);
      await tx.orderEvent.create({ data: { orderId: order.id, status: next, note: note || null } });
      return tx.order.findUnique({ where: { id: order.id } });
    });
    if (next === 'COMPLETED' && order.driverId) {
      await prisma.driver.update({ where: { userId: order.driverId }, data: { completedTrips: { increment: 1 }, online: true } });
      await settleCompletedOrder(order.id);
    }
    return updated;
  }

  @Post('/ratings') async rating(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h);
    const order = await prisma.order.findFirst({ where: { id: b.orderId, status: OrderStatus.COMPLETED, OR: [{ customerId: u.id }, { driverId: u.id }] } });
    if (!order) throw new HttpException('Оценку можно поставить только по завершённому заказу', 400);
    const toUserId = u.id === order.customerId ? order.driverId : order.customerId;
    if (!toUserId) throw new HttpException('В заказе нет второго участника', 400);
    const stars = Number(b.stars);
    if (!Number.isInteger(stars) || stars < 1 || stars > 5) throw new HttpException('Оценка от 1 до 5', 400);
    const exists = await prisma.rating.findFirst({ where: { orderId: order.id, fromUserId: u.id } });
    if (exists) throw new HttpException('Вы уже оценили этот заказ', 409);
    const result = await prisma.$transaction(async tx => {
      const r = await tx.rating.create({ data: { orderId: order.id, fromUserId: u.id, toUserId, stars, comment: String(b.comment || '').trim() || null } });
      const avg = await tx.rating.aggregate({ where: { toUserId }, _avg: { stars: true } });
      if (order.driverId === toUserId) await tx.driver.update({ where: { userId: toUserId }, data: { rating: avg._avg.stars || 0 } });
      return r;
    });
    return result;
  }

  @Post('/notifications/token') async saveNotificationToken(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h);
    const token = String(b.token || '').trim();
    if (!token) throw new HttpException('FCM token обязателен', 400);
    return prisma.notificationToken.upsert({ where: { token }, update: { userId: u.id, platform: String(b.platform || '').trim() || null }, create: { userId: u.id, token, platform: String(b.platform || '').trim() || null } });
  }

  @Get('/notifications/tokens') async notificationTokens(@Headers() h: any) {
    const u = await this.api.userFromHeaders(h);
    return prisma.notificationToken.findMany({ where: { userId: u.id }, select: { id: true, platform: true, createdAt: true, updatedAt: true } });
  }

  @Get('/orders/:orderId/messages') async messages(@Headers() h: any, @Param('orderId') orderId: string, @Query('after') after?: string) {
    const u = await this.api.userFromHeaders(h);
    const order = await prisma.order.findFirst({ where: { id: orderId, OR: [{ customerId: u.id }, { driverId: u.id }] } });
    if (!order) throw new HttpException('Заказ не найден', 404);
    if (after && Number.isNaN(new Date(after).getTime())) throw new HttpException('Некорректная дата параметра after', 400);
    return prisma.message.findMany({ where: { orderId, ...(after ? { createdAt: { gt: new Date(after) } } : {}) }, include: { sender: { select: { id: true, name: true, surname: true, role: true } } }, orderBy: { createdAt: 'asc' }, take: 200 });
  }

  @Post('/orders/:orderId/messages') async sendMessage(@Headers() h: any, @Param('orderId') orderId: string, @Body() b: any) {
    const u = await this.api.userFromHeaders(h);
    const order = await prisma.order.findFirst({ where: { id: orderId, OR: [{ customerId: u.id }, { driverId: u.id }] } });
    if (!order) throw new HttpException('Заказ не найден', 404);
    const text = String(b.text || '').trim();
    if (!text || text.length > 2000) throw new HttpException('Сообщение пустое или слишком длинное', 400);
    const msg = await prisma.message.create({ data: { orderId, senderId: u.id, text }, include: { sender: { select: { id: true, name: true, surname: true, role: true } } } });
    return msg;
  }

  @Post('/payments/create') async createPayment(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h);
    if (u.role !== UserRole.CUSTOMER) throw new HttpException('Только для заказчика', 403);
    const orderId = String(b.orderId || '');
    const key = String(b.idempotencyKey || '').trim();
    if (!orderId || !key) throw new HttpException('orderId и idempotencyKey обязательны', 400);
    const order = await prisma.order.findFirst({ where: { id: orderId, customerId: u.id } });
    if (!order) throw new HttpException('Заказ не найден', 404);
    if (!order.driverId || !['DRIVER_SELECTED','EN_ROUTE_TO_PICKUP'].includes(order.status)) throw new HttpException('Оплатить можно после выбора водителя', 400);
    const payment = await prisma.payment.upsert({
      where: { idempotencyKey: key },
      update: {},
      create: { orderId: order.id, customerId: u.id, amountKzt: order.priceKzt, idempotencyKey: key, provider: PAYMENT_PROVIDER, status: PaymentStatus.PENDING }
    });
    if (payment.customerId !== u.id || payment.orderId !== order.id) throw new HttpException('Этот idempotencyKey уже используется для другого платежа', 409);
    if (payment.status !== PaymentStatus.PENDING) return payment;
    try {
      const gateway = await freedomPayCreate(order, u, payment.id);
      if (gateway) return prisma.payment.update({ where: { id: payment.id }, data: { providerRef: gateway.providerRef, paymentUrl: gateway.paymentUrl, status: PaymentStatus.INITIATED } });
    } catch (e) {
      await prisma.payment.update({ where: { id: payment.id }, data: { status: PaymentStatus.FAILED } });
      throw e;
    }
    return payment;
  }

  @Post('/payments/freedompay/result') async freedomResult(@Body() b: any) {
    if (PAYMENT_PROVIDER !== 'FREEDOMPAY' || !FREEDOMPAY_SECRET_KEY) return 'error';
    const orderRef = String(b.pg_order_id || '');
    const paymentId = String(b.pg_payment_id || '');
    if (!orderRef) return 'error';
    const payment = await prisma.payment.findUnique({ where: { id: orderRef } });
    if (!payment) return 'error';
    const fields: Record<string, any> = { ...b }; delete fields.pg_sig;
    if (!b.pg_salt || freedomSignature('/result', fields, FREEDOMPAY_SECRET_KEY) !== String(b.pg_sig || '')) return 'error';
    const amount = Number(b.pg_amount);
    if (Number.isFinite(amount) && Math.round(amount) !== payment.amountKzt) return 'error';
    const successful = ['ok','success','1'].includes(String(b.pg_status || b.pg_result || '').toLowerCase());
    await prisma.payment.update({ where: { id: payment.id }, data: { status: successful ? PaymentStatus.PAID : PaymentStatus.FAILED, providerRef: paymentId || payment.providerRef } });
    return 'ok';
  }

  @Get('/payments/freedompay/success') async freedomSuccess() { return '<!doctype html><meta charset=\"utf-8\"><h2>Оплата получена</h2><p>Вернитесь в приложение «Груз Казахстан» и обновите заказ.</p>'; }
  @Get('/payments/freedompay/failure') async freedomFailure() { return '<!doctype html><meta charset=\"utf-8\"><h2>Оплата не завершена</h2><p>Вернитесь в приложение и попробуйте ещё раз.</p>'; }

  @Get('/payments/order/:orderId') async orderPayment(@Headers() h: any, @Param('orderId') orderId: string) {
    const u = await this.api.userFromHeaders(h);
    const order = await prisma.order.findFirst({ where: { id: orderId, OR: [{ customerId: u.id }, { driverId: u.id }] } });
    if (!order) throw new HttpException('Заказ не найден', 404);
    return prisma.payment.findFirst({ where: { orderId }, orderBy: { createdAt: 'desc' } });
  }

  @Post('/admin/payments/mark-paid') async markPaymentPaid(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.ADMIN) throw new HttpException('Только администратор', 403);
    if (process.env.NODE_ENV === 'production' && process.env.ALLOW_MANUAL_PAYMENT_CONFIRMATION !== 'true') throw new HttpException('Ручное подтверждение платежа отключено в production', 403);
    const id = String(b.paymentId || '');
    return prisma.payment.update({ where: { id }, data: { status: PaymentStatus.PAID, providerRef: String(b.providerRef || '').trim() || null } });
  }

  @Get('/finance/my') async myFinance(@Headers() h: any) {
    const u = await this.api.userFromHeaders(h);
    const rows = await prisma.financialTransaction.findMany({ where: { userId: u.id }, orderBy: { createdAt: 'desc' }, take: 100 });
    const driver = u.driver ? await prisma.driver.findUnique({ where: { userId: u.id }, select: { walletBalanceKzt: true, totalEarnedKzt: true, totalCommissionKzt: true } }) : null;
    return { balanceKzt: driver?.walletBalanceKzt ?? 0, totalEarnedKzt: driver?.totalEarnedKzt ?? 0, totalCommissionKzt: driver?.totalCommissionKzt ?? 0, transactions: rows };
  }

  @Post('/finance/payout-request') async payoutRequest(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h);
    if (u.role !== UserRole.DRIVER || !u.driver || u.driver.status !== DriverStatus.VERIFIED) throw new HttpException('Только проверенный водитель', 403);
    const amount = Math.floor(Number(b.amountKzt));
    const method = String(b.method || '').trim();
    const last4 = String(b.destinationLast4 || '').replace(/\D/g, '').slice(-4) || null;
    if (!Number.isInteger(amount) || amount < 1000) throw new HttpException('Минимальная сумма выплаты — 1 000 ₸', 400);
    if (!method) throw new HttpException('Укажите способ выплаты', 400);
    if (!last4) throw new HttpException('Укажите последние 4 цифры счёта/карты', 400);
    return prisma.$transaction(async tx => {
      const d = await tx.driver.findUnique({ where: { userId: u.id }, select: { walletBalanceKzt: true } });
      if (!d || d.walletBalanceKzt < amount) throw new HttpException('Недостаточно средств на балансе', 400);
      const pending = await tx.payoutRequest.findFirst({ where: { driverId: u.id, status: 'PENDING' } });
      if (pending) throw new HttpException('У вас уже есть заявка на выплату', 409);
      return tx.payoutRequest.create({ data: { driverId: u.id, amountKzt: amount, method, destinationLast4: last4 } });
    });
  }

  @Get('/finance/payouts') async myPayouts(@Headers() h: any) {
    const u = await this.api.userFromHeaders(h);
    if (u.role !== UserRole.DRIVER) throw new HttpException('Только водитель', 403);
    return prisma.payoutRequest.findMany({ where: { driverId: u.id }, orderBy: { createdAt: 'desc' }, take: 50 });
  }

  @Get('/admin/finance/payouts') async adminPayouts(@Headers() h: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.ADMIN) throw new HttpException('Только администратор', 403);
    return prisma.payoutRequest.findMany({ where: { status: 'PENDING' }, orderBy: { createdAt: 'asc' }, include: { driver: { select: { id: true, name: true, surname: true, phone: true } } } });
  }

  @Post('/admin/finance/payouts/approve') async approvePayout(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.ADMIN) throw new HttpException('Только администратор', 403);
    const requestId = String(b.requestId || '');
    return prisma.$transaction(async tx => {
      const req = await tx.payoutRequest.findUnique({ where: { id: requestId } });
      if (!req || req.status !== 'PENDING') throw new HttpException('Заявка не найдена или уже обработана', 404);
      const d = await tx.driver.findUnique({ where: { userId: req.driverId }, select: { walletBalanceKzt: true } });
      if (!d || d.walletBalanceKzt < req.amountKzt) throw new HttpException('Недостаточно средств на балансе', 400);
      await tx.driver.update({ where: { userId: req.driverId }, data: { walletBalanceKzt: { decrement: req.amountKzt } } });
      await tx.financialTransaction.create({ data: { userId: req.driverId, type: 'PAYOUT', status: 'POSTED', amountKzt: -req.amountKzt, description: `Выплата ${req.amountKzt} ₸ (${req.method}, ****${req.destinationLast4})` } });
      return tx.payoutRequest.update({ where: { id: req.id }, data: { status: 'PAID', adminNote: String(b.note || '').trim() || null } });
    });
  }

  @Post('/admin/finance/payouts/reject') async rejectPayout(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.ADMIN) throw new HttpException('Только администратор', 403);
    const req = await prisma.payoutRequest.findUnique({ where: { id: String(b.requestId || '') } });
    if (!req || req.status !== 'PENDING') throw new HttpException('Заявка не найдена или уже обработана', 404);
    return prisma.payoutRequest.update({ where: { id: req.id }, data: { status: 'REJECTED', adminNote: String(b.note || 'Заявка отклонена').trim() } });
  }

  @Get('/admin/finance/commission') async commission(@Headers() h: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.ADMIN) throw new HttpException('Только администратор', 403);
    return { percent: await getCommissionPercent() };
  }

  @Post('/admin/finance/commission') async setCommission(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.ADMIN) throw new HttpException('Только администратор', 403);
    const percent = Number(b.percent);
    if (!Number.isFinite(percent) || percent < 0 || percent > 100) throw new HttpException('Комиссия должна быть от 0 до 100%', 400);
    return prisma.commissionSetting.upsert({ where: { id: 'default' }, update: { percent }, create: { id: 'default', percent } });
  }

  @Get('/admin/finance/summary') async financeSummary(@Headers() h: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.ADMIN) throw new HttpException('Только администратор', 403);
    const [commission, earning, payout, refund] = await Promise.all([
      prisma.financialTransaction.aggregate({ where: { type: 'PLATFORM_COMMISSION', status: 'POSTED' }, _sum: { amountKzt: true } }),
      prisma.financialTransaction.aggregate({ where: { type: 'DRIVER_EARNING', status: 'POSTED' }, _sum: { amountKzt: true } }),
      prisma.financialTransaction.aggregate({ where: { type: 'PAYOUT', status: 'POSTED' }, _sum: { amountKzt: true } }),
      prisma.financialTransaction.aggregate({ where: { type: 'REFUND', status: 'POSTED' }, _sum: { amountKzt: true } })
    ]);
    return { commissionKzt: commission._sum.amountKzt ?? 0, driverEarningsKzt: earning._sum.amountKzt ?? 0, payoutsKzt: payout._sum.amountKzt ?? 0, refundsKzt: refund._sum.amountKzt ?? 0 };
  }

  @Get('/admin/finance/transactions') async financeTransactions(@Headers() h: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.ADMIN) throw new HttpException('Только администратор', 403);
    return prisma.financialTransaction.findMany({ orderBy: { createdAt: 'desc' }, take: 200, include: { user: { select: { id: true, name: true, surname: true, phone: true } }, order: { select: { id: true, priceKzt: true, status: true, cargoDescription: true } } } });
  }

  @Get('/admin/drivers/pending') async pending(@Headers() h: any) { const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.ADMIN) throw new HttpException('Только администратор', 403); return prisma.driver.findMany({ where: { status: DriverStatus.PENDING }, include: { user: { select: { id: true, name: true, surname: true, phone: true } }, vehicles: true, documents: true }, orderBy: { createdAt: 'asc' } }); }

  @Post('/admin/verify-driver') async verify(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.ADMIN) throw new HttpException('Только администратор', 403);
    const status = b.approve ? DriverStatus.VERIFIED : DriverStatus.REJECTED;
    return prisma.driver.update({ where: { userId: b.userId }, data: { status, rejectionReason: b.approve ? null : String(b.reason || 'Документы не прошли проверку') } });
  }

  @Post('/admin/verify-document') async verifyDocument(@Headers() h: any, @Body() b: any) {
    const u = await this.api.userFromHeaders(h); if (u.role !== UserRole.ADMIN) throw new HttpException('Только администратор', 403);
    return prisma.driverDocument.update({ where: { id: b.documentId }, data: { status: b.approve ? DocumentStatus.VERIFIED : DocumentStatus.REJECTED } });
  }
}

function publicUser(u: any) { return { id: u.id, phone: u.phone, name: u.name, surname: u.surname, role: u.role, driver: u.driver ? { id: u.driver.id, status: u.driver.status, city: u.driver.city, licenseNumber: u.driver.licenseNumber, experienceYears: u.driver.experienceYears, profilePhotoUrl: u.driver.profilePhotoUrl, rejectionReason: u.driver.rejectionReason, rating: u.driver.rating, completedTrips: u.driver.completedTrips, online: u.driver.online, currentLat: u.driver.currentLat, currentLon: u.driver.currentLon, locationUpdatedAt: u.driver.locationUpdatedAt, vehicles: u.driver.vehicles, documents: u.driver.documents } : null }; }

@Module({ imports: [JwtModule.register({ secret: process.env.JWT_SECRET || '', signOptions: { expiresIn: '30d' } })], controllers: [AppController], providers: [ApiService] }) class AppModule {}

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const jwtSecret = process.env.JWT_SECRET || '';
  if (!jwtSecret || jwtSecret.length < 32 || jwtSecret === 'CHANGE_THIS_SECRET_IN_PRODUCTION') throw new Error('JWT_SECRET обязателен и должен содержать минимум 32 символа');
  const allowedOrigins = (process.env.CORS_ORIGINS || (process.env.NODE_ENV === 'development' ? '*' : '')).split(',').map(x => x.trim()).filter(Boolean);
  if (process.env.NODE_ENV === 'production' && allowedOrigins.includes('*')) throw new Error('CORS_ORIGINS не должен быть * в production');
  app.enableCors({ origin: allowedOrigins.includes('*') ? true : allowedOrigins });
  const http = app.getHttpAdapter().getInstance();
  http.disable('x-powered-by');
  http.use((_req: Request, res: Response, next: NextFunction) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'no-referrer');
    next();
  });
  http.use('/api/auth/', rateLimit(20, 60_000, 'auth'));
  http.use('/api/payments/', rateLimit(30, 60_000, 'payments'));
  http.use('/api/uploads', rateLimit(20, 60_000, 'uploads'));

  http.use('/uploads', express.static(uploadDir, { fallthrough: false }));
  http.use('/admin', express.static(path.join(process.cwd(), 'admin')));
  await prisma.$connect();
  await app.listen(Number(process.env.PORT) || 3000);
  const shutdown = async () => { await app.close(); await prisma.$disconnect(); process.exit(0); };
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
}
bootstrap().catch(async err => { console.error('Backend startup failed:', err); await prisma.$disconnect(); process.exit(1); });
