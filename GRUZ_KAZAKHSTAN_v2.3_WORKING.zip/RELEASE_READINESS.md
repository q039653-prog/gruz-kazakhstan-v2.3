# Груз Казахстан — v2.3 release readiness

## Что исправлено в этой сборке
- Версии mobile/backend/API приведены к 2.3.0 (mobile build 23).
- Удалена дублирующая базовая Prisma-миграция, которая ломала чистую установку БД.
- Добавлены v2.3 типы транспорта и поля кузова/характеристик.
- Усилена серверная валидация регистрации, SMS-кода, заказа, координат и платежей.
- Переходы статусов заказа сделаны атомарными.
- Добавлено событие создания заказа.
- Усилена идемпотентность платежа.
- Добавлены ограничения целостности для сообщений и оценок.
- Убраны небезопасные значения администратора по умолчанию.
- Добавлена отдельная Web CI-сборка и backend CI-проверка.
- Исправлена совместимость загрузки изображений Flutter с Web.
- Freedom Pay endpoint/signature callback приведены к актуальной схеме интеграции.

## Что всё ещё требует реального внешнего окружения
Это не ошибки исходников, а обязательные данные/сервисы владельца проекта:
- production PostgreSQL;
- длинный случайный JWT_SECRET (минимум 32 символа);
- production CORS_ORIGINS без `*`;
- SMSC.KZ credentials;
- 2GIS API key;
- Firebase Android/iOS/Web configuration и server credentials;
- Freedom Pay merchant credentials и публичный HTTPS backend;
- Android signing / Google Play Console;
- Apple Developer/App Store Connect;
- реальный device testing.

## Веб
Web собирается через Flutter CI. Для работающей web-версии при сборке нужно передать:
`--dart-define=API_BASE_URL=https://ВАШ-BACKEND/api`

## Важно
До прохождения CI и реального device/end-to-end теста проект нельзя называть полностью production-ready.
