#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../mobile"
command -v flutter >/dev/null 2>&1 || { echo 'Flutter SDK is required. Install stable Flutter first.'; exit 1; }
flutter create --platforms=android,ios --org kz.gruzkazakhstan .
# Keep the existing application code and dependency manifest; flutter create only adds platform scaffolding.
flutter pub get
flutter analyze
