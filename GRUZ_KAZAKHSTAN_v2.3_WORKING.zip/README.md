# Груз Казахстан v2.3

Коммерческий маркетплейс грузоперевозок Казахстана: заказчики, водители, предложения цены, доставка, попутный груз, чат, оценки, финансы, платежи и уведомления.

## v2.3
- расширенные типы транспорта: КамАЗ, ЗИЛ, MAN, Volvo, Scania, самосвал, манипулятор, рефрижератор, тент, фура, бортовой грузовик, эвакуатор;
- грузоподъёмность, объём, тип кузова и характеристики автомобиля;
- атомарный выбор водителя;
- попутный груз с повторной серверной проверкой маршрута;
- SMS OTP, JWT, FCM foundation, чат, оценки, комиссия, баланс и выплаты;
- Freedom Pay adapter;
- Android/iOS CI и Web CI.

## Важное
Настоящая карта 2ГИС требует ключа `DGIS_API_KEY` на backend и `dgissdk.key` для мобильного SDK. Ключи нельзя публиковать в GitHub.

Web/Android/iOS требуют сборки Flutter в CI или на машине с Flutter SDK. Production также требует реальные credentials внешних сервисов.

## Локальный backend
1. Node.js 20+ и Docker.
2. Скопировать `backend/.env.example` в `.env` и заполнить обязательные значения.
3. `docker compose up -d` из `backend`.
4. `npm install`
5. `npx prisma generate`
6. `npx prisma migrate deploy`
7. `npm run build`
8. `npm start`

После запуска health: `/api/health`.

## Мобильная/Web сборка
`flutter pub get`

Для реального backend: `flutter build web --release --dart-define=API_BASE_URL=https://ВАШ-BACKEND/api`

Android: `flutter build appbundle --release --dart-define=API_BASE_URL=https://ВАШ-BACKEND/api`

## Безопасность
Не используйте тестовые секреты в production. Администратор создаётся только через `ADMIN_PHONE` и `ADMIN_PASSWORD`.
